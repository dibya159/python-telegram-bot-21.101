"""Reusable InlineKeyboardMarkup builders."""

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

from game_data import ITEMS, WEAPON_KEYS, ARMOR_KEYS, POTION_KEYS


def main_menu_keyboard():
    rows = [
        [InlineKeyboardButton("👤 Profile", callback_data="menu:profile"),
         InlineKeyboardButton("⚔️ Hunt", callback_data="menu:hunt")],
        [InlineKeyboardButton("🛒 Shop", callback_data="menu:shop"),
         InlineKeyboardButton("🎒 Inventory", callback_data="menu:inventory")],
        [InlineKeyboardButton("🎁 Daily", callback_data="menu:daily"),
         InlineKeyboardButton("🏆 Leaderboard", callback_data="menu:leaderboard")],
        [InlineKeyboardButton("📖 Achievements", callback_data="menu:achievements"),
         InlineKeyboardButton("❓ Help", callback_data="menu:help")],
    ]
    return InlineKeyboardMarkup(rows)


def battle_keyboard(has_potion: bool):
    row = [InlineKeyboardButton("⚔️ Attack", callback_data="battle:attack")]
    if has_potion:
        row.append(InlineKeyboardButton("🧪 Heal", callback_data="battle:heal"))
    row.append(InlineKeyboardButton("🏃 Flee", callback_data="battle:flee"))
    return InlineKeyboardMarkup([row])


def battle_end_keyboard():
    rows = [[
        InlineKeyboardButton("⚔️ Hunt Again", callback_data="menu:hunt"),
        InlineKeyboardButton("👤 Profile", callback_data="menu:profile"),
    ]]
    return InlineKeyboardMarkup(rows)


def shop_keyboard():
    rows = []
    for key in WEAPON_KEYS + ARMOR_KEYS + POTION_KEYS:
        item = ITEMS[key]
        label = f"{item['emoji']} {item['name']} - {item['price']}g"
        rows.append([InlineKeyboardButton(label, callback_data=f"shop:buy:{key}")])
    rows.append([InlineKeyboardButton("⬅️ Back", callback_data="menu:main")])
    return InlineKeyboardMarkup(rows)


def inventory_keyboard(inventory_rows):
    rows = []
    for row in inventory_rows:
        item = ITEMS.get(row["item_key"])
        if not item:
            continue
        tag = " ✅" if row["equipped"] else ""
        label = f"{item['emoji']} {item['name']} x{row['quantity']}{tag}"
        if item["type"] in ("weapon", "armor"):
            action = f"inv:equip:{row['item_key']}"
        else:
            action = f"inv:use:{row['item_key']}"
        rows.append([InlineKeyboardButton(label, callback_data=action)])
    rows.append([InlineKeyboardButton("⬅️ Back", callback_data="menu:main")])
    return InlineKeyboardMarkup(rows)


def duel_challenge_keyboard(challenger_id: int, opponent_id: int):
    rows = [[
        InlineKeyboardButton("✅ Accept", callback_data=f"duel:accept:{challenger_id}:{opponent_id}"),
        InlineKeyboardButton("❌ Decline", callback_data=f"duel:decline:{challenger_id}:{opponent_id}"),
    ]]
    return InlineKeyboardMarkup(rows)


def back_keyboard():
    return InlineKeyboardMarkup([[InlineKeyboardButton("⬅️ Back", callback_data="menu:main")]])
