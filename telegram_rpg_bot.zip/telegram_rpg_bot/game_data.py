"""
Static game content: items, monsters, achievement definitions.
Kept as plain Python data so it's easy to extend without touching logic code.
"""

# item_key -> item definition
ITEMS = {
    # --- weapons ---
    "wooden_sword":  {"name": "Wooden Sword",  "type": "weapon", "price": 60,   "atk": 4,  "def": 0,  "emoji": "🗡️"},
    "iron_sword":    {"name": "Iron Sword",    "type": "weapon", "price": 200,  "atk": 10, "def": 0,  "emoji": "⚔️"},
    "steel_axe":     {"name": "Steel Axe",     "type": "weapon", "price": 500,  "atk": 18, "def": 0,  "emoji": "🪓"},
    "flame_blade":   {"name": "Flame Blade",   "type": "weapon", "price": 1200, "atk": 30, "def": 0,  "emoji": "🔥"},
    "dragon_fang":   {"name": "Dragon Fang",   "type": "weapon", "price": 3000, "atk": 50, "def": 0,  "emoji": "🐉"},

    # --- armor ---
    "leather_armor": {"name": "Leather Armor", "type": "armor",  "price": 60,   "atk": 0,  "def": 4,  "emoji": "🥋"},
    "chainmail":     {"name": "Chainmail",     "type": "armor",  "price": 200,  "atk": 0,  "def": 10, "emoji": "🛡️"},
    "iron_plate":    {"name": "Iron Plate",    "type": "armor",  "price": 500,  "atk": 0,  "def": 18, "emoji": "🛡️"},
    "royal_armor":   {"name": "Royal Armor",   "type": "armor",  "price": 1200, "atk": 0,  "def": 30, "emoji": "👑"},
    "dragon_scale":  {"name": "Dragon Scale",  "type": "armor",  "price": 3000, "atk": 0,  "def": 50, "emoji": "🐲"},

    # --- consumables ---
    "small_potion":  {"name": "Small Potion",  "type": "potion", "price": 25,   "heal": 30, "emoji": "🧪"},
    "large_potion":  {"name": "Large Potion",  "type": "potion", "price": 70,   "heal": 80, "emoji": "🧴"},
    "revive_scroll": {"name": "Revive Scroll", "type": "potion", "price": 150,  "heal": 999, "emoji": "📜"},
}

WEAPON_KEYS = [k for k, v in ITEMS.items() if v["type"] == "weapon"]
ARMOR_KEYS = [k for k, v in ITEMS.items() if v["type"] == "armor"]
POTION_KEYS = [k for k, v in ITEMS.items() if v["type"] == "potion"]

# Monsters scale roughly with player level. min_level is the lowest player
# level at which the monster can appear.
MONSTERS = [
    {"name": "Slime",          "emoji": "🟢", "hp": 25,  "atk": 4,  "def": 1,  "min_level": 1,  "xp": 15,  "gold": (5, 15)},
    {"name": "Giant Rat",      "emoji": "🐀", "hp": 35,  "atk": 6,  "def": 2,  "min_level": 1,  "xp": 20,  "gold": (8, 18)},
    {"name": "Goblin",         "emoji": "👺", "hp": 55,  "atk": 9,  "def": 3,  "min_level": 2,  "xp": 30,  "gold": (12, 25)},
    {"name": "Wild Boar",      "emoji": "🐗", "hp": 70,  "atk": 12, "def": 4,  "min_level": 3,  "xp": 40,  "gold": (15, 30)},
    {"name": "Skeleton",       "emoji": "💀", "hp": 90,  "atk": 15, "def": 6,  "min_level": 4,  "xp": 55,  "gold": (20, 40)},
    {"name": "Orc Warrior",    "emoji": "👹", "hp": 130, "atk": 20, "def": 9,  "min_level": 6,  "xp": 75,  "gold": (30, 55)},
    {"name": "Dark Mage",      "emoji": "🧙", "hp": 110, "atk": 26, "def": 5,  "min_level": 8,  "xp": 95,  "gold": (40, 70)},
    {"name": "Troll",          "emoji": "🧌", "hp": 200, "atk": 25, "def": 14, "min_level": 10, "xp": 130, "gold": (55, 90)},
    {"name": "Vampire Lord",   "emoji": "🧛", "hp": 250, "atk": 32, "def": 16, "min_level": 13, "xp": 170, "gold": (70, 120)},
    {"name": "Ancient Dragon", "emoji": "🐉", "hp": 400, "atk": 45, "def": 25, "min_level": 18, "xp": 260, "gold": (120, 200)},
]

# achievement_key -> (display name, description)
ACHIEVEMENTS = {
    "first_blood":     ("🩸 First Blood",       "Win your first battle"),
    "monster_hunter":  ("⚔️ Monster Hunter",    "Win 25 battles"),
    "veteran":         ("🎖️ Veteran",           "Win 100 battles"),
    "level_5":         ("🌟 Rising Star",       "Reach level 5"),
    "level_10":        ("✨ Seasoned Adventurer","Reach level 10"),
    "level_20":        ("🌠 Legendary Hero",    "Reach level 20"),
    "rich_1000":       ("💰 Gold Collector",    "Hold 1,000 gold at once"),
    "rich_10000":      ("🏆 Wealthy Merchant",  "Hold 10,000 gold at once"),
    "duelist":         ("🤺 Duelist",           "Win your first PvP duel"),
    "duel_champion":   ("👑 Duel Champion",     "Win 10 PvP duels"),
    "well_equipped":   ("🎒 Well Equipped",     "Own 5 different items"),
    "streak_7":        ("📅 Dedicated",         "Claim daily reward 7 days in a row"),
}
