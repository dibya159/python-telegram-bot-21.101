"""
Pure(ish) game logic: combat resolution, leveling, equipment stat totals,
and achievement checks. Kept separate from Telegram handling so it's easy
to test and reason about.
"""

import random

import database as db
from config import XP_PER_LEVEL_BASE
from game_data import ITEMS, MONSTERS, ACHIEVEMENTS, WEAPON_KEYS, ARMOR_KEYS


def xp_needed_for_level(level: int) -> int:
    return level * XP_PER_LEVEL_BASE


def equipped_bonus(user_id: int):
    """Sum atk/def bonuses from all equipped items."""
    atk_bonus, def_bonus = 0, 0
    for row in db.get_inventory(user_id):
        if row["equipped"]:
            item = ITEMS.get(row["item_key"])
            if item:
                atk_bonus += item.get("atk", 0)
                def_bonus += item.get("def", 0)
    return atk_bonus, def_bonus


def effective_stats(user: dict):
    """Base stats + equipped gear bonuses."""
    atk_bonus, def_bonus = equipped_bonus(user["user_id"])
    return {
        "attack": user["attack"] + atk_bonus,
        "defense": user["defense"] + def_bonus,
        "max_hp": user["max_hp"],
    }


def pick_monster(player_level: int):
    """Weighted random monster appropriate for the player's level."""
    eligible = [m for m in MONSTERS if m["min_level"] <= player_level]
    if not eligible:
        eligible = [MONSTERS[0]]
    # Bias toward monsters closer to the player's level (last few eligible)
    pool = eligible[-4:] if len(eligible) > 4 else eligible
    monster = dict(random.choice(pool))
    monster["max_hp"] = monster["hp"]
    return monster


def compute_damage(attacker_atk: int, defender_def: int) -> int:
    """Damage with light randomness and a defense mitigation curve."""
    base = max(1, attacker_atk - defender_def // 2)
    variance = random.uniform(0.8, 1.2)
    crit = random.random() < 0.1
    dmg = int(base * variance * (1.5 if crit else 1.0))
    return max(1, dmg), crit


def grant_xp_and_level(user_id: int, xp_gain: int) -> dict:
    """Adds XP, handles (possibly multiple) level-ups. Returns summary dict."""
    user = db.get_user(user_id)
    xp = user["xp"] + xp_gain
    level = user["level"]
    max_hp = user["max_hp"]
    attack = user["attack"]
    defense = user["defense"]
    levels_gained = 0

    while xp >= xp_needed_for_level(level):
        xp -= xp_needed_for_level(level)
        level += 1
        levels_gained += 1
        max_hp += 15
        attack += 3
        defense += 2

    update = {"xp": xp, "level": level}
    if levels_gained > 0:
        update["max_hp"] = max_hp
        update["attack"] = attack
        update["defense"] = defense
        update["hp"] = max_hp  # full heal on level up
    db.update_user(user_id, **update)
    return {"levels_gained": levels_gained, "new_level": level}


def check_achievements(user_id: int) -> list:
    """Run all achievement checks for a user; returns newly unlocked ones
    as a list of (key, name, description)."""
    user = db.get_user(user_id)
    unlocked_now = []
    already = db.get_achievements(user_id)

    def try_unlock(key, condition):
        if key not in already and condition:
            if db.unlock_achievement(user_id, key):
                name, desc = ACHIEVEMENTS[key]
                unlocked_now.append((key, name, desc))

    try_unlock("first_blood", user["wins"] >= 1)
    try_unlock("monster_hunter", user["wins"] >= 25)
    try_unlock("veteran", user["wins"] >= 100)
    try_unlock("level_5", user["level"] >= 5)
    try_unlock("level_10", user["level"] >= 10)
    try_unlock("level_20", user["level"] >= 20)
    try_unlock("rich_1000", user["gold"] >= 1000)
    try_unlock("rich_10000", user["gold"] >= 10000)
    try_unlock("streak_7", user["streak"] >= 7)
    try_unlock("duelist", user["duel_wins"] >= 1)
    try_unlock("duel_champion", user["duel_wins"] >= 10)

    inv = db.get_inventory(user_id)
    try_unlock("well_equipped", len(inv) >= 5)

    return unlocked_now


def hp_bar(current: int, maximum: int, length: int = 10) -> str:
    current = max(0, current)
    filled = int(length * current / maximum) if maximum > 0 else 0
    filled = min(length, filled)
    return "🟩" * filled + "⬜" * (length - filled) + f"  {current}/{maximum}"


def xp_bar(current: int, needed: int, length: int = 10) -> str:
    filled = int(length * current / needed) if needed > 0 else 0
    filled = min(length, filled)
    return "🟦" * filled + "⬜" * (length - filled) + f"  {current}/{needed}"
