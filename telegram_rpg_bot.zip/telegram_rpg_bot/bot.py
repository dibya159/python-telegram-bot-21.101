"""
Realm of Ashes — a Telegram RPG bot.

Run with:
    export BOT_TOKEN="your-token-here"
    python bot.py
"""

import logging

from telegram import Update
from telegram.ext import (
    Application,
    ApplicationBuilder,
    CommandHandler,
    CallbackQueryHandler,
    ContextTypes,
)

from config import BOT_TOKEN
import database as db

from handlers.start import start_cmd, main_menu_callback
from handlers.profile import profile_cmd
from handlers.battle import start_hunt, battle_action_callback
from handlers.shop import shop_cmd, shop_buy_callback
from handlers.inventory import inventory_cmd, inventory_equip_callback, inventory_use_callback
from handlers.daily import daily_cmd
from handlers.duel import duel_cmd, duel_response_callback
from handlers.leaderboard import leaderboard_cmd
from handlers.achievements import achievements_cmd
from handlers.help import help_cmd

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# callback_data prefix ("menu:<key>") -> handler function
MENU_ROUTES = {
    "main": main_menu_callback,
    "profile": profile_cmd,
    "hunt": start_hunt,
    "shop": shop_cmd,
    "inventory": inventory_cmd,
    "daily": daily_cmd,
    "leaderboard": leaderboard_cmd,
    "achievements": achievements_cmd,
    "help": help_cmd,
}


async def menu_dispatch(update: Update, context: ContextTypes.DEFAULT_TYPE):
    key = update.callback_query.data.split(":")[1]
    handler = MENU_ROUTES.get(key)
    if handler:
        await handler(update, context)
    else:
        await update.callback_query.answer("Unknown menu option.", show_alert=True)


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    logger.error("Exception while handling an update:", exc_info=context.error)
    if isinstance(update, Update):
        chat = update.effective_chat
        if chat:
            try:
                await context.bot.send_message(
                    chat_id=chat.id,
                    text="⚠️ Something went wrong. Please try again with /start.",
                )
            except Exception:
                pass


def build_application() -> Application:
    db.init_db()

    application = ApplicationBuilder().token(BOT_TOKEN).build()

    # --- commands ---
    application.add_handler(CommandHandler("start", start_cmd))
    application.add_handler(CommandHandler("profile", profile_cmd))
    application.add_handler(CommandHandler("hunt", start_hunt))
    application.add_handler(CommandHandler("shop", shop_cmd))
    application.add_handler(CommandHandler("inventory", inventory_cmd))
    application.add_handler(CommandHandler("daily", daily_cmd))
    application.add_handler(CommandHandler("duel", duel_cmd))
    application.add_handler(CommandHandler("leaderboard", leaderboard_cmd))
    application.add_handler(CommandHandler("achievements", achievements_cmd))
    application.add_handler(CommandHandler("help", help_cmd))

    # --- callback queries ---
    application.add_handler(CallbackQueryHandler(menu_dispatch, pattern=r"^menu:"))
    application.add_handler(CallbackQueryHandler(battle_action_callback, pattern=r"^battle:"))
    application.add_handler(CallbackQueryHandler(shop_buy_callback, pattern=r"^shop:buy:"))
    application.add_handler(CallbackQueryHandler(inventory_equip_callback, pattern=r"^inv:equip:"))
    application.add_handler(CallbackQueryHandler(inventory_use_callback, pattern=r"^inv:use:"))
    application.add_handler(CallbackQueryHandler(duel_response_callback, pattern=r"^duel:"))

    application.add_error_handler(error_handler)

    return application


def main():
    application = build_application()
    logger.info("Realm of Ashes bot starting...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
