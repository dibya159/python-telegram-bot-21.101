# ⚔️ Realm of Ashes — Telegram RPG Bot

A full-featured, professionally structured RPG game bot for Telegram, built with
[python-telegram-bot](https://github.com/python-telegram-bot/python-telegram-bot) (v21, async)
and SQLite.

## Features

- **Character system** — level, XP, HP, Attack, Defense, Gold, all persisted per user
- **Monster hunting (`/hunt`)** — turn-based battles vs. 10 different monsters that scale
  with your level, with Attack / Heal / Flee options via inline buttons
- **Shop (`/shop`)** — 5 weapon tiers, 5 armor tiers, 3 potion types to buy with gold
- **Inventory (`/inventory`)** — equip weapons/armor, view potions
- **Daily rewards (`/daily`)** — gold reward with a streak bonus (resets if you miss a day)
- **PvP duels (`/duel`)** — reply to another player's message to challenge them; battles
  are simulated using both players' effective stats, winner takes a small gold stake
- **Leaderboard (`/leaderboard`)** — top 10 players by level/XP/gold
- **Achievements (`/achievements`)** — 12 unlockable achievements across combat, leveling,
  wealth, dueling, and gear collection, with toast notifications when unlocked
- **Main menu** — every feature is also reachable via inline buttons from `/start`, no
  need to memorize commands

## Project structure

```
telegram_rpg_bot/
├── bot.py              # entry point — wires up all handlers
├── config.py            # bot token & gameplay tuning constants
├── database.py           # SQLite persistence layer
├── game_data.py           # static data: items, monsters, achievements
├── game_logic.py           # combat math, leveling, achievement checks
├── keyboards.py            # inline keyboard builders
├── handlers/
│   ├── common.py           # shared reply/edit helper
│   ├── start.py             # /start + main menu
│   ├── profile.py            # /profile
│   ├── battle.py              # /hunt + battle callbacks
│   ├── shop.py                 # /shop + purchase callbacks
│   ├── inventory.py             # /inventory + equip/use callbacks
│   ├── daily.py                   # /daily
│   ├── duel.py                     # /duel + PvP callbacks
│   ├── leaderboard.py               # /leaderboard
│   ├── achievements.py               # /achievements
│   └── help.py                        # /help
└── requirements.txt
```

## Setup

1. **Get a bot token** from [@BotFather](https://t.me/BotFather) on Telegram
   (`/newbot`, follow the prompts).

2. **Install dependencies** (Python 3.10+ required):
   ```bash
   pip install -r requirements.txt
   ```

3. **Set your token** as an environment variable:
   ```bash
   export BOT_TOKEN="123456789:AAExampleTokenFromBotFather"
   ```
   (On Windows PowerShell: `$env:BOT_TOKEN="..."`)

4. **Run the bot**:
   ```bash
   python bot.py
   ```

The bot uses long polling, so no public URL/webhook is required — it works out of
the box on a laptop, VPS, or any always-on machine.

A `game.db` SQLite file is created automatically in the working directory on first run.

## How it plays

- `/start` — opens the main menu with buttons for every feature
- `/hunt` — fight a monster; tap **Attack** each turn, **Heal** if you're carrying a
  potion, or **Flee** to bail out with no reward. Winning grants XP and gold; leveling
  up increases your max HP, Attack, and Defense and fully heals you
- `/shop` — buy better weapons/armor to raise your effective Attack/Defense, or
  potions to survive tougher fights
- `/inventory` — equip your best gear (only one weapon + one armor active at a time)
- `/daily` — claim a free gold reward once every 24h; keep your streak alive for
  bigger bonuses
- `/duel` (as a **reply** to someone's message) — challenge them to PvP; they get an
  Accept/Decline button, and the fight resolves instantly with a small gold stake
- `/leaderboard` — see how you rank
- `/achievements` — track your unlockables

## Extending the game

- Add new items in `game_data.py` → `ITEMS` (and to `WEAPON_KEYS`/`ARMOR_KEYS`/`POTION_KEYS`
  if adding a new category)
- Add new monsters in `game_data.py` → `MONSTERS`
- Add new achievements in `game_data.py` → `ACHIEVEMENTS`, then add the unlock condition
  in `game_logic.py` → `check_achievements()`
- Gameplay tuning (cooldowns, XP curve, starting stats) lives entirely in `config.py`

## Notes on scaling

This bot uses SQLite with a simple threading lock, which comfortably handles a bot
with up to a few thousand active users on a single process. For very high traffic,
swap `database.py`'s sqlite3 calls for PostgreSQL/MySQL with an async driver — the
rest of the codebase (handlers, game logic) doesn't need to change since it only
talks to `database.py`'s function interface.
