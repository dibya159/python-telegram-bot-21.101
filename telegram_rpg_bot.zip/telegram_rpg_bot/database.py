"""
SQLite persistence layer.

All functions are synchronous (sqlite3 is fast enough for a single-process
bot at moderate scale). A module-level lock guards writes so concurrent
async handlers don't corrupt the file.
"""

import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone

from config import DB_PATH, STARTING_GOLD, STARTING_HP, STARTING_ATTACK, STARTING_DEFENSE

_lock = threading.Lock()


def _connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def get_conn():
    with _lock:
        conn = _connect()
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()


def init_db():
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                level INTEGER NOT NULL DEFAULT 1,
                xp INTEGER NOT NULL DEFAULT 0,
                hp INTEGER NOT NULL DEFAULT 100,
                max_hp INTEGER NOT NULL DEFAULT 100,
                attack INTEGER NOT NULL DEFAULT 10,
                defense INTEGER NOT NULL DEFAULT 5,
                gold INTEGER NOT NULL DEFAULT 100,
                wins INTEGER NOT NULL DEFAULT 0,
                losses INTEGER NOT NULL DEFAULT 0,
                duel_wins INTEGER NOT NULL DEFAULT 0,
                streak INTEGER NOT NULL DEFAULT 0,
                last_daily TEXT,
                last_explore TEXT,
                created_at TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS inventory (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                item_key TEXT NOT NULL,
                quantity INTEGER NOT NULL DEFAULT 1,
                equipped INTEGER NOT NULL DEFAULT 0,
                UNIQUE(user_id, item_key),
                FOREIGN KEY(user_id) REFERENCES users(user_id)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS achievements (
                user_id INTEGER NOT NULL,
                achievement_key TEXT NOT NULL,
                unlocked_at TEXT,
                PRIMARY KEY (user_id, achievement_key)
            )
        """)


# ---------------------------------------------------------------- users ---

def get_user(user_id: int):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM users WHERE user_id = ?", (user_id,)).fetchone()
        return dict(row) if row else None


def create_user(user_id: int, username: str):
    now = datetime.now(timezone.utc).isoformat()
    with get_conn() as conn:
        conn.execute("""
            INSERT OR IGNORE INTO users
                (user_id, username, level, xp, hp, max_hp, attack, defense, gold,
                 wins, losses, duel_wins, streak, last_daily, last_explore, created_at)
            VALUES (?, ?, 1, 0, ?, ?, ?, ?, ?, 0, 0, 0, 0, NULL, NULL, ?)
        """, (user_id, username, STARTING_HP, STARTING_HP, STARTING_ATTACK,
              STARTING_DEFENSE, STARTING_GOLD, now))
    return get_user(user_id)


def get_or_create_user(user_id: int, username: str):
    user = get_user(user_id)
    if user is None:
        user = create_user(user_id, username)
    elif username and user.get("username") != username:
        update_user(user_id, username=username)
        user["username"] = username
    return user


def update_user(user_id: int, **fields):
    if not fields:
        return
    cols = ", ".join(f"{k} = ?" for k in fields)
    values = list(fields.values()) + [user_id]
    with get_conn() as conn:
        conn.execute(f"UPDATE users SET {cols} WHERE user_id = ?", values)


def top_users(limit: int = 10):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM users ORDER BY level DESC, xp DESC, gold DESC LIMIT ?",
            (limit,)
        ).fetchall()
        return [dict(r) for r in rows]


# ------------------------------------------------------------ inventory ---

def add_item(user_id: int, item_key: str, qty: int = 1):
    with get_conn() as conn:
        conn.execute("""
            INSERT INTO inventory (user_id, item_key, quantity, equipped)
            VALUES (?, ?, ?, 0)
            ON CONFLICT(user_id, item_key) DO UPDATE SET quantity = quantity + excluded.quantity
        """, (user_id, item_key, qty))


def remove_item(user_id: int, item_key: str, qty: int = 1):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT quantity FROM inventory WHERE user_id = ? AND item_key = ?",
            (user_id, item_key)
        ).fetchone()
        if not row:
            return False
        new_qty = row["quantity"] - qty
        if new_qty <= 0:
            conn.execute("DELETE FROM inventory WHERE user_id = ? AND item_key = ?",
                         (user_id, item_key))
        else:
            conn.execute("UPDATE inventory SET quantity = ? WHERE user_id = ? AND item_key = ?",
                         (new_qty, user_id, item_key))
        return True


def get_inventory(user_id: int):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM inventory WHERE user_id = ? ORDER BY item_key", (user_id,)
        ).fetchall()
        return [dict(r) for r in rows]


def get_inventory_item(user_id: int, item_key: str):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM inventory WHERE user_id = ? AND item_key = ?",
            (user_id, item_key)
        ).fetchone()
        return dict(row) if row else None


def set_equipped(user_id: int, item_key: str, slot_type: str, all_item_keys_of_type: list):
    """Unequip all items of the same slot type, then equip the chosen one."""
    with get_conn() as conn:
        if all_item_keys_of_type:
            placeholders = ",".join("?" * len(all_item_keys_of_type))
            conn.execute(
                f"UPDATE inventory SET equipped = 0 WHERE user_id = ? AND item_key IN ({placeholders})",
                [user_id] + all_item_keys_of_type
            )
        conn.execute(
            "UPDATE inventory SET equipped = 1 WHERE user_id = ? AND item_key = ?",
            (user_id, item_key)
        )


# --------------------------------------------------------- achievements ---

def unlock_achievement(user_id: int, key: str) -> bool:
    """Returns True if newly unlocked, False if already had it."""
    now = datetime.now(timezone.utc).isoformat()
    with get_conn() as conn:
        try:
            conn.execute(
                "INSERT INTO achievements (user_id, achievement_key, unlocked_at) VALUES (?, ?, ?)",
                (user_id, key, now)
            )
            return True
        except sqlite3.IntegrityError:
            return False


def get_achievements(user_id: int):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT achievement_key FROM achievements WHERE user_id = ?", (user_id,)
        ).fetchall()
        return {r["achievement_key"] for r in rows}
