from telegram import Update
from telegram.ext import ContextTypes

import database as db
from keyboards import main_menu_keyboard
from handlers.common import respond, display_name

WELCOME_TEXT = (
    "⚔️ <b>Welcome to Realm of Ashes!</b> ⚔️\n\n"
    "A text RPG you play right here in Telegram.\n"
    "Hunt monsters, level up, gear up at the shop, duel other players, "
    "and climb the leaderboard.\n\n"
    "Choose an option below to begin your journey:"
)


async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tg_user = update.effective_user
    db.get_or_create_user(tg_user.id, display_name(tg_user))
    await respond(update, context, WELCOME_TEXT, main_menu_keyboard())


async def main_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await respond(update, context, WELCOME_TEXT, main_menu_keyboard())
