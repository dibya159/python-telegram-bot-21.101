from telegram import Update
from telegram.ext import ContextTypes

import database as db
from game_data import ACHIEVEMENTS
from keyboards import back_keyboard
from handlers.common import respond, display_name


async def achievements_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tg_user = update.effective_user
    db.get_or_create_user(tg_user.id, display_name(tg_user))
    unlocked = db.get_achievements(tg_user.id)

    lines = ["📖 <b>Achievements</b>\n"]
    for key, (name, desc) in ACHIEVEMENTS.items():
        mark = "✅" if key in unlocked else "🔒"
        lines.append(f"{mark} <b>{name}</b> — {desc}")

    lines.append(f"\nUnlocked: {len(unlocked)}/{len(ACHIEVEMENTS)}")
    await respond(update, context, "\n".join(lines), back_keyboard())
