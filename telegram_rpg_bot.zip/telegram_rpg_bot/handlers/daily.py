from datetime import datetime, timezone

from telegram import Update
from telegram.ext import ContextTypes

import database as db
import game_logic as gl
from config import DAILY_BASE_REWARD, DAILY_STREAK_BONUS, DAILY_STREAK_CAP
from keyboards import back_keyboard
from handlers.common import respond, display_name, announce_achievements


async def daily_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tg_user = update.effective_user
    user = db.get_or_create_user(tg_user.id, display_name(tg_user))
    now = datetime.now(timezone.utc)

    if user["last_daily"]:
        last = datetime.fromisoformat(user["last_daily"])
        hours_since = (now - last).total_seconds() / 3600
        if hours_since < 24:
            wait_h = 24 - hours_since
            await respond(update, context,
                          f"⏳ You already claimed today's reward.\nCome back in {wait_h:.1f}h.",
                          back_keyboard())
            return
        streak = user["streak"] + 1 if hours_since < 48 else 1
    else:
        streak = 1

    bonus = DAILY_STREAK_BONUS * min(streak, DAILY_STREAK_CAP)
    reward = DAILY_BASE_REWARD + bonus

    db.update_user(tg_user.id, gold=user["gold"] + reward, streak=streak,
                    last_daily=now.isoformat())

    text = (f"🎁 <b>Daily Reward Claimed!</b>\n\n"
            f"💰 +{reward} gold ({DAILY_BASE_REWARD} base + {bonus} streak bonus)\n"
            f"🔥 Streak: {streak} day(s)\n\n"
            f"Come back tomorrow to keep your streak alive!")
    await respond(update, context, text, back_keyboard())

    unlocked = gl.check_achievements(tg_user.id)
    await announce_achievements(update, context, unlocked)
