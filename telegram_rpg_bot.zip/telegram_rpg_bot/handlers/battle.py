from datetime import datetime, timezone

from telegram import Update
from telegram.ext import ContextTypes

import database as db
import game_logic as gl
from config import EXPLORE_COOLDOWN_SECONDS
from game_data import ITEMS, POTION_KEYS
from keyboards import battle_keyboard, battle_end_keyboard, back_keyboard
from handlers.common import respond, notify, display_name, announce_achievements


def _seconds_since(iso_ts: str) -> float:
    then = datetime.fromisoformat(iso_ts)
    return (datetime.now(timezone.utc) - then).total_seconds()


def _best_potion(user_id: int):
    """Pick the strongest owned potion (by heal amount) for auto-heal button."""
    best = None
    for row in db.get_inventory(user_id):
        if row["item_key"] in POTION_KEYS and row["quantity"] > 0:
            item = ITEMS[row["item_key"]]
            if best is None or item["heal"] > ITEMS[best]["heal"]:
                best = row["item_key"]
    return best


def _render_battle(state: dict, log_line: str = "") -> str:
    m = state["monster"]
    text = (
        f"⚔️ <b>Battle: {m['emoji']} {m['name']}</b>\n\n"
        f"{m['emoji']} {m['name']}: {gl.hp_bar(m['hp'], m['max_hp'])}\n"
        f"🧑 You: {gl.hp_bar(state['player_hp'], state['player_max_hp'])}\n"
    )
    if log_line:
        text += f"\n{log_line}"
    return text


async def start_hunt(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tg_user = update.effective_user
    user = db.get_or_create_user(tg_user.id, display_name(tg_user))

    if context.user_data.get("battle"):
        await respond(update, context, "⚠️ You're already in a battle! Finish it first.",
                      battle_keyboard(_best_potion(tg_user.id) is not None))
        return

    if user["last_explore"]:
        elapsed = _seconds_since(user["last_explore"])
        if elapsed < EXPLORE_COOLDOWN_SECONDS:
            wait = int(EXPLORE_COOLDOWN_SECONDS - elapsed)
            await respond(update, context, f"⏳ You're tired from your last hunt. Wait {wait}s.",
                          back_keyboard())
            return

    db.update_user(tg_user.id, last_explore=datetime.now(timezone.utc).isoformat())

    stats = gl.effective_stats(user)
    monster = gl.pick_monster(user["level"])

    state = {
        "monster": monster,
        "player_hp": user["max_hp"],
        "player_max_hp": user["max_hp"],
        "atk": stats["attack"],
        "def": stats["defense"],
    }
    context.user_data["battle"] = state
    db.update_user(tg_user.id, hp=user["max_hp"])  # rest to full before the hunt

    text = (f"A wild {monster['emoji']} <b>{monster['name']}</b> appears!\n\n"
            + _render_battle(state))
    await respond(update, context, text, battle_keyboard(_best_potion(tg_user.id) is not None))


async def _end_battle(update, context, user_id, won: bool, fled: bool, state: dict):
    context.user_data.pop("battle", None)
    m = state["monster"]

    if fled:
        await respond(update, context, "🏃 You fled the battle. No rewards this time.",
                      battle_end_keyboard())
        return

    if won:
        import random
        gold_gain = random.randint(*m["gold"])
        db.update_user(user_id, gold=db.get_user(user_id)["gold"] + gold_gain,
                        hp=state["player_hp"],
                        wins=db.get_user(user_id)["wins"] + 1)
        level_info = gl.grant_xp_and_level(user_id, m["xp"])

        text = (f"🎉 <b>Victory!</b> You defeated {m['emoji']} {m['name']}!\n\n"
                f"✨ +{m['xp']} XP\n💰 +{gold_gain} Gold")
        if level_info["levels_gained"] > 0:
            text += f"\n\n🆙 <b>Level up!</b> You are now level {level_info['new_level']}!"

        await respond(update, context, text, battle_end_keyboard())
        unlocked = gl.check_achievements(user_id)
        await announce_achievements(update, context, unlocked)
    else:
        user = db.get_user(user_id)
        gold_loss = min(user["gold"], max(0, int(user["gold"] * 0.1)))
        recover_hp = max(1, int(state["player_max_hp"] * 0.3))
        db.update_user(user_id, gold=user["gold"] - gold_loss, hp=recover_hp,
                        losses=user["losses"] + 1)
        text = (f"💀 <b>Defeat!</b> {m['emoji']} {m['name']} was too strong.\n\n"
                f"💸 Lost {gold_loss} gold. You limp back to town and recover.")
        await respond(update, context, text, battle_end_keyboard())


async def battle_action_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = update.effective_user.id
    action = query.data.split(":")[1]

    state = context.user_data.get("battle")
    if not state:
        await query.answer("No active battle. Use /hunt to start one.", show_alert=True)
        return

    m = state["monster"]
    log_lines = []

    if action == "flee":
        await _end_battle(update, context, user_id, won=False, fled=True, state=state)
        return

    if action == "heal":
        potion_key = _best_potion(user_id)
        if not potion_key:
            await query.answer("You have no potions!", show_alert=True)
            return
        item = ITEMS[potion_key]
        healed = min(item["heal"], state["player_max_hp"] - state["player_hp"])
        state["player_hp"] = min(state["player_max_hp"], state["player_hp"] + item["heal"])
        db.remove_item(user_id, potion_key, 1)
        log_lines.append(f"🧪 You used {item['name']} and healed {healed} HP.")
    else:  # attack
        dmg, crit = gl.compute_damage(state["atk"], m["def"])
        m["hp"] = max(0, m["hp"] - dmg)
        log_lines.append(f"⚔️ You hit {m['name']} for {dmg} damage" + (" (CRIT!)" if crit else "") + ".")

    # Check monster defeated
    if m["hp"] <= 0:
        await query.answer()
        await _end_battle(update, context, user_id, won=True, fled=False, state=state)
        return

    # Monster retaliates
    mdmg, mcrit = gl.compute_damage(m["atk"], state["def"])
    state["player_hp"] = max(0, state["player_hp"] - mdmg)
    log_lines.append(f"{m['emoji']} {m['name']} hits you for {mdmg} damage" + (" (CRIT!)" if mcrit else "") + ".")

    if state["player_hp"] <= 0:
        await query.answer()
        await _end_battle(update, context, user_id, won=False, fled=False, state=state)
        return

    await query.answer()
    text = _render_battle(state, "\n".join(log_lines))
    try:
        await query.edit_message_text(
            text, reply_markup=battle_keyboard(_best_potion(user_id) is not None), parse_mode="HTML"
        )
    except Exception:
        pass
