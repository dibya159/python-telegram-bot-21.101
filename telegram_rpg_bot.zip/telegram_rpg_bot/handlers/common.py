"""Small shared utilities for handlers (send-or-edit, username formatting)."""

from telegram import Update
from telegram.ext import ContextTypes


async def respond(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, reply_markup=None):
    """Reply to a command message, or edit the message for a callback query.
    Falls back to a fresh message if editing fails (e.g. message too old)."""
    if update.callback_query:
        await update.callback_query.answer()
        try:
            await update.callback_query.edit_message_text(
                text, reply_markup=reply_markup, parse_mode="HTML"
            )
        except Exception:
            await update.callback_query.message.reply_text(
                text, reply_markup=reply_markup, parse_mode="HTML"
            )
    else:
        await update.message.reply_text(text, reply_markup=reply_markup, parse_mode="HTML")


async def notify(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
    """Send a standalone new message (e.g. achievement unlock toast) without
    disturbing the main menu/battle message."""
    chat_id = update.effective_chat.id
    await context.bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML")


def display_name(user) -> str:
    if user.username:
        return f"@{user.username}"
    return user.first_name or "Adventurer"


async def announce_achievements(update, context, unlocked):
    for _key, name, desc in unlocked:
        await notify(update, context, f"🏅 <b>Achievement unlocked!</b>\n{name}\n<i>{desc}</i>")
