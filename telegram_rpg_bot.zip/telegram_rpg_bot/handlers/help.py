from telegram import Update
from telegram.ext import ContextTypes

from keyboards import back_keyboard
from handlers.common import respond

HELP_TEXT = (
    "❓ <b>Commands</b>\n\n"
    "/start — Open the main menu\n"
    "/profile — View your character stats\n"
    "/hunt — Fight a random monster\n"
    "/shop — Buy weapons, armor & potions\n"
    "/inventory — View & equip your items\n"
    "/daily — Claim your daily gold reward\n"
    "/duel — Reply to someone's message with this to challenge them to PvP\n"
    "/leaderboard — See the top adventurers\n"
    "/achievements — Track your progress\n"
    "/help — Show this message\n\n"
    "<i>Tip: equip better weapons and armor from the shop to take on tougher monsters!</i>"
)


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await respond(update, context, HELP_TEXT, back_keyboard())
