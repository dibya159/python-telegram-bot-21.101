from telegram import Update
from telegram.ext import ContextTypes

import database as db
from config import LEADERBOARD_SIZE
from keyboards import back_keyboard
from handlers.common import respond, display_name

MEDALS = ["🥇", "🥈", "🥉"]


async def leaderboard_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tg_user = update.effective_user
    db.get_or_create_user(tg_user.id, display_name(tg_user))

    top = db.top_users(LEADERBOARD_SIZE)
    if not top:
        await respond(update, context, "🏆 <b>Leaderboard</b>\n\nNo adventurers yet!", back_keyboard())
        return

    lines = ["🏆 <b>Top Adventurers</b>\n"]
    for i, u in enumerate(top):
        rank = MEDALS[i] if i < 3 else f"{i + 1}."
        name = u.get("username") or f"Player {u['user_id']}"
        lines.append(f"{rank} <b>{name}</b> — Lv.{u['level']} | {u['gold']}g | {u['wins']}W")

    await respond(update, context, "\n".join(lines), back_keyboard())
