from telegram import Update
from telegram.ext import ContextTypes

import database as db
import game_logic as gl
from keyboards import back_keyboard
from handlers.common import respond, display_name


def render_profile(user: dict) -> str:
    stats = gl.effective_stats(user)
    needed = gl.xp_needed_for_level(user["level"])
    total_battles = user["wins"] + user["losses"]
    win_rate = (user["wins"] / total_battles * 100) if total_battles else 0.0

    return (
        f"👤 <b>{user.get('username') or 'Adventurer'}</b>\n\n"
        f"🏅 Level: <b>{user['level']}</b>\n"
        f"✨ XP: {gl.xp_bar(user['xp'], needed)}\n"
        f"❤️ HP: {gl.hp_bar(user['hp'], user['max_hp'])}\n\n"
        f"⚔️ Attack: <b>{stats['attack']}</b> (base {user['attack']})\n"
        f"🛡️ Defense: <b>{stats['defense']}</b> (base {user['defense']})\n"
        f"💰 Gold: <b>{user['gold']}</b>\n\n"
        f"📊 Wins: {user['wins']} | Losses: {user['losses']} | Win rate: {win_rate:.0f}%\n"
        f"🔥 Daily streak: {user['streak']} day(s)"
    )


async def profile_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tg_user = update.effective_user
    user = db.get_or_create_user(tg_user.id, display_name(tg_user))
    await respond(update, context, render_profile(user), back_keyboard())
