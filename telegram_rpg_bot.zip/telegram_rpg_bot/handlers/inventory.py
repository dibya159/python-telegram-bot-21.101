from telegram import Update
from telegram.ext import ContextTypes

import database as db
import game_logic as gl
from game_data import ITEMS, WEAPON_KEYS, ARMOR_KEYS
from keyboards import inventory_keyboard
from handlers.common import respond, display_name, announce_achievements


def render_inventory_text(inv_rows) -> str:
    if not inv_rows:
        return "🎒 <b>Inventory</b>\n\nYour bag is empty. Visit the /shop to gear up!"
    return "🎒 <b>Inventory</b>\n\nTap a weapon/armor to equip it, or a potion to use info about it:"


async def inventory_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tg_user = update.effective_user
    db.get_or_create_user(tg_user.id, display_name(tg_user))
    inv = db.get_inventory(tg_user.id)
    await respond(update, context, render_inventory_text(inv), inventory_keyboard(inv))


async def inventory_equip_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = update.effective_user.id
    item_key = query.data.split(":")[2]
    item = ITEMS.get(item_key)
    if not item:
        await query.answer("Unknown item.", show_alert=True)
        return

    slot_keys = WEAPON_KEYS if item["type"] == "weapon" else ARMOR_KEYS
    db.set_equipped(user_id, item_key, item["type"], slot_keys)
    await query.answer(f"Equipped {item['name']}! ✅")

    unlocked = gl.check_achievements(user_id)
    await announce_achievements(update, context, unlocked)

    inv = db.get_inventory(user_id)
    try:
        await query.edit_message_text(render_inventory_text(inv), reply_markup=inventory_keyboard(inv),
                                       parse_mode="HTML")
    except Exception:
        pass


async def inventory_use_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    item_key = query.data.split(":")[2]
    item = ITEMS.get(item_key)
    if not item:
        await query.answer("Unknown item.", show_alert=True)
        return
    await query.answer(f"{item['name']} heals {item['heal']} HP. Use it during a battle with the Heal button!",
                        show_alert=True)
