from telegram import Update
from telegram.ext import ContextTypes

import database as db
import game_logic as gl
from keyboards import duel_challenge_keyboard, battle_end_keyboard
from handlers.common import notify, display_name, announce_achievements

DUEL_STAKE = 20


async def duel_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    challenger = update.effective_user
    db.get_or_create_user(challenger.id, display_name(challenger))

    if not update.message.reply_to_message:
        await update.message.reply_text(
            "⚔️ To challenge someone to a duel, reply to one of their messages with /duel."
        )
        return

    opponent = update.message.reply_to_message.from_user
    if opponent.is_bot:
        await update.message.reply_text("You can't duel a bot!")
        return
    if opponent.id == challenger.id:
        await update.message.reply_text("You can't duel yourself!")
        return

    db.get_or_create_user(opponent.id, display_name(opponent))

    text = (f"⚔️ <b>Duel Challenge!</b>\n\n"
            f"{display_name(challenger)} has challenged {display_name(opponent)} to a duel!\n"
            f"Stake: {DUEL_STAKE} gold\n\n"
            f"{display_name(opponent)}, do you accept?")
    await update.message.reply_text(
        text, reply_markup=duel_challenge_keyboard(challenger.id, opponent.id), parse_mode="HTML"
    )


def _simulate_duel(a_stats, b_stats):
    """Turn-based simulation. Returns True if A wins."""
    a_hp, b_hp = a_stats["max_hp"], b_stats["max_hp"]
    turn_a = True
    rounds = 0
    while a_hp > 0 and b_hp > 0 and rounds < 100:
        if turn_a:
            dmg, _ = gl.compute_damage(a_stats["attack"], b_stats["defense"])
            b_hp -= dmg
        else:
            dmg, _ = gl.compute_damage(b_stats["attack"], a_stats["defense"])
            a_hp -= dmg
        turn_a = not turn_a
        rounds += 1
    return a_hp >= b_hp


async def duel_response_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    parts = query.data.split(":")
    action = parts[1]
    challenger_id = int(parts[2])
    opponent_id = int(parts[3])
    clicker_id = update.effective_user.id

    if clicker_id != opponent_id:
        await query.answer("Only the challenged player can respond to this duel!", show_alert=True)
        return

    if action == "decline":
        await query.answer("Duel declined.")
        await query.edit_message_text("❌ Duel declined.")
        return

    await query.answer()

    challenger = db.get_user(challenger_id)
    opponent = db.get_user(opponent_id)

    stake = min(DUEL_STAKE, challenger["gold"], opponent["gold"])

    a_stats = gl.effective_stats(challenger)
    a_stats["max_hp"] = challenger["max_hp"]
    b_stats = gl.effective_stats(opponent)
    b_stats["max_hp"] = opponent["max_hp"]

    challenger_wins = _simulate_duel(a_stats, b_stats)

    if challenger_wins:
        winner_id, loser_id = challenger_id, opponent_id
    else:
        winner_id, loser_id = opponent_id, challenger_id

    winner = db.get_user(winner_id)
    loser = db.get_user(loser_id)
    db.update_user(winner_id, gold=winner["gold"] + stake, duel_wins=winner["duel_wins"] + 1)
    db.update_user(loser_id, gold=loser["gold"] - stake)

    challenger_name = challenger.get("username") or "Challenger"
    opponent_name = opponent.get("username") or "Opponent"
    winner_name = challenger_name if winner_id == challenger_id else opponent_name

    text = (f"⚔️ <b>Duel Result</b>\n\n"
            f"🏆 <b>{winner_name}</b> wins the duel!\n"
            f"💰 Gold won: {stake}")
    await query.edit_message_text(text, reply_markup=battle_end_keyboard(), parse_mode="HTML")

    unlocked = gl.check_achievements(winner_id)
    if unlocked:
        for _key, name, desc in unlocked:
            await context.bot.send_message(
                chat_id=update.effective_chat.id,
                text=f"🏅 <b>Achievement unlocked!</b>\n{name}\n<i>{desc}</i>",
                parse_mode="HTML",
            )
