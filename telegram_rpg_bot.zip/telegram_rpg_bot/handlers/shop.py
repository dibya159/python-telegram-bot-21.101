from telegram import Update
from telegram.ext import ContextTypes

import database as db
from game_data import ITEMS
from keyboards import shop_keyboard
from handlers.common import respond, display_name

SHOP_TEXT = (
    "🛒 <b>Adventurer's Shop</b>\n\n"
    "Spend your gold on weapons, armor, and potions.\n"
    "Weapons increase Attack, armor increases Defense, potions heal you in battle.\n\n"
    "Tap an item to purchase it:"
)


async def shop_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    tg_user = update.effective_user
    db.get_or_create_user(tg_user.id, display_name(tg_user))
    await respond(update, context, SHOP_TEXT, shop_keyboard())


async def shop_buy_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = update.effective_user.id
    item_key = query.data.split(":")[2]
    item = ITEMS.get(item_key)

    if not item:
        await query.answer("Unknown item.", show_alert=True)
        return

    user = db.get_or_create_user(user_id, display_name(update.effective_user))
    if user["gold"] < item["price"]:
        await query.answer(f"Not enough gold! You need {item['price']}g.", show_alert=True)
        return

    db.update_user(user_id, gold=user["gold"] - item["price"])
    db.add_item(user_id, item_key, 1)
    await query.answer(f"Purchased {item['name']}! ✅")

    text = SHOP_TEXT + f"\n\n✅ Bought {item['emoji']} <b>{item['name']}</b> for {item['price']}g."
    try:
        await query.edit_message_text(text, reply_markup=shop_keyboard(), parse_mode="HTML")
    except Exception:
        pass
